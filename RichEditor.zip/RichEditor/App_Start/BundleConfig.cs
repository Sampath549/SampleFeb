﻿using System.Web;
using System.Web.Optimization;

namespace RichEditor.App_Start
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/Content/css").Include(
                    "~/Content/css/bootstrap.css",
                    "~/Content/css/font-awesome.css",
                    "~/Content/css/site.css"
                  ));

            bundles.Add(new StyleBundle("~/Content/summernote").Include(
                "~/Content/summernote/summernote.css"
                ));

            bundles.Add(new ScriptBundle("~/bundle/base").Include(
               "~/Scripts/jquery-1.10.2.js",
                "~/Scripts/bootstrap.js"
               ));

            bundles.Add(new ScriptBundle("~/bundle/summernote").Include(
               "~/Content/summernote/summernote.js"
               ));
        }
    }
}
