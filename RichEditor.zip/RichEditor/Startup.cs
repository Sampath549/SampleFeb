﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RichEditor.Startup))]
namespace RichEditor
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
