﻿using Microsoft.Office.Interop.Word;
using RichEditor.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Xceed.Words.NET;

namespace RichEditor.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            HomeViewModel model = new HomeViewModel();
            return View();
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult Index(HomeViewModel model)
        {
            try
            {
                string _DateValue = DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
                string _TimeValue = DateTime.Now.ToString("hh.mm.ss tt");
                string _FileName = model.Title + " " + _DateValue + " " + _TimeValue;

                DocX document = null;
                document = DocX.Create(Server.MapPath("~/WordDocuments/" + _FileName + ".docx"), DocumentTypes.Document);
                var _Format = new Formatting();
                document.InsertParagraph(model.Content, false, _Format);
                document.Save();

                ////For Download
                //MemoryStream ms = new MemoryStream();
                //document.SaveAs(ms);
                //// document.Save(ms, SaveFormat.Docx);
                //byte[] byteArray = ms.ToArray();
                //ms.Flush();
                //ms.Close();
                //ms.Dispose();
                //Response.Clear();
                //Response.AddHeader("Content-Disposition", "attachment; filename=report.docx");
                //Response.AddHeader("Content-Length", byteArray.Length.ToString());
                //Response.ContentType = "application/msword";
                //Response.BinaryWrite(byteArray);
                //Response.End();
                ViewBag.Message = "File Saved Successfully..!";
                ModelState.Clear();
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Message = "File Saving Failed" + " " + ex.Message;
                return View();
            }


            //return View(model);
        }

        public ActionResult DocumentList()
        {
            IList<DocList> _List = new List<DocList>();
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["DisplayDocs"]))
            {
                DirectoryInfo d = new DirectoryInfo(Server.MapPath("~/WordDocuments"));
                FileInfo[] Files = d.GetFiles("*.docx"); //Getting Text files

                int k = 1;
                foreach (FileInfo file in Files)
                {
                    _List.Add(new DocList
                    {
                        Id = Convert.ToInt32(k),
                        DocName = file.Name,
                    });
                    k++;
                }
            }
            return View(_List);
        }

        public ActionResult HTMLView(DocList _lst)
        {
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["DisplayDocs"]))
            {
                string DocName = _lst.DocName;

                DirectoryInfo d = new DirectoryInfo(Server.MapPath("~/WordDocuments")); //Assuming Test is your Folder
                FileInfo[] Files = d.GetFiles("*.docx"); //Getting Text files

                foreach (FileInfo file in Files)
                {
                    if (DocName == file.Name)
                    {
                        Application application = new Application();
                        Document document = application.Documents.Open(Server.MapPath("~/WordDocuments/" + DocName));

                        string allWords = document.Content.Text; //Get all words
                        document.Close();
                        application.Quit();

                        ViewBag.Message = allWords;
                    }
                }
            }
            return View();
        }

        public ActionResult HTMLDelete(DocList _lst)
        {
            if (Convert.ToBoolean(ConfigurationManager.AppSettings["DisplayDocs"]))
            {
                string DocName = _lst.DocName;

                DirectoryInfo d = new DirectoryInfo(Server.MapPath("~/WordDocuments")); //Assuming Test is your Folder
                FileInfo[] Files = d.GetFiles("*.docx"); //Getting Text files

                foreach (FileInfo file in Files)
                {
                    if (DocName == file.Name)
                    {
                        System.IO.File.Delete(Server.MapPath(("~/WordDocuments/") + DocName));
                        return RedirectToAction("DocumentList", "Home");
                    }
                }
            }
            return View();
        }
    }
}